The QwirkleServer.bat file used to run the server uses the JAVA_HOME
environment variable therefore the operating system should have java installed and the JAVA_HOME 
environment variable set. e.g., "C:\Program Files\Java\jdk-17.0.1" excluding the bin folder.